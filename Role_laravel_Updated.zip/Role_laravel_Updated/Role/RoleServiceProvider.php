<?php 

/**
 * @version xxx v.1
 * @author Rajkumar sakthivel
 * 
 */
namespace Src\xxx\Role;
use Src\xxx\ModulesServiceProvider;
 
class RoleServiceProvider extends ModulesServiceProvider {
 
/**
* register.
*/
    public function register() {
        parent::register('Role');
    }

/**
* boot.
*/
    public function boot() {
        parent::boot('Role');
    }
}