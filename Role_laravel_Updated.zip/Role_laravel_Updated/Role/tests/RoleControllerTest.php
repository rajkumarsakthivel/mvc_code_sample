<?php

/**
 * file name : RoleControllerTest.php
 * @version   v.1
 * @author    Rajkumar sakthivel 
 * 
 */
class RoleControllerTest extends TestCase
{

    public function __Construct()
    {
        $this->mock = Mockery::mock( 'Eloquent', 'Src\xxx\Role\Models\Role' );
    }

    public function setUp()
    {
        parent::setUp();
        $this->app->instance( 'Src\xxx\Role\Models\Role', $this->mock );
    }

    public function tearDown()
    {
        Mockery::close();
    }

    public function testList()
    {
        $this->call( 'GET', 'role/list' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }


    public function testAdd()
    {
        $this->client->request( 'GET', 'role/add' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }


    public function testEdit()
    {
        $this->client->request( 'GET', 'role/edit/1' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }

    public function testStatus()
    {
        $this->client->request( 'GET', 'role/status/1' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }

    public function testCreateSuccess()
    {
        Input::replace( $input = [ 'name' => 'MyTitle' ] );
        $this->mock
            ->shouldReceive( 'create' )
            ->once()
            ->with( $input );
        $this->app->instance( 'Src\xxxx\Role\Models\Role', $this->mock );
        $this->call( 'POST', 'role/create' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }

    public function testCreateFails()
    {
        Input::replace( $input = [ 'name' => '' ] );
        $this->mock
            ->shouldReceive( 'create' )
            ->once()
            ->with( $input );
        $this->app->instance( 'Src\xxx\Role\Models\Role', $this->mock );
        $this->call( 'POST', 'role/create' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }

    public function testUpdateSuccess()
    {
        Input::replace( $input = [ 'name' => 'MyTitle' ] );
        $this->mock
            ->shouldReceive( 'update' )
            ->once()
            ->with( $input );
        $this->app->instance( 'Src\xxxx\Role\Models\Role', $this->mock );
        $this->call( 'POST', 'role/update' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }

    public function testUpdateFails()
    {
        Input::replace( $input = [ 'name' => '' ] );
        $this->mock
            ->shouldReceive( 'update' )
            ->once()
            ->with( $input );
        $this->app->instance( 'Src\xxxx\Role\Models\Role', $this->mock );
        $this->call( 'POST', 'role/update' );
        $this->assertTrue( $this->client->getResponse()->isOk() );
    }

}