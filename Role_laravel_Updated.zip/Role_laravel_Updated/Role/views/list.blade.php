@extends('Site::layouts.main')
@section('content')
<div>
    <ul class="breadcrumb">
        <li>
            <a href="{{ URL::to('site/dashboard') }}">Home</a> <span class="divider">/</span>
        </li>
        <li>
            <a href="{{ URL::to('role/list') }}">User Roles</a>
        </li>
    </ul>
</div>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-user"></i>&nbsp;User Roles</h2>
        </div>
        @if( Session::has('message') )
        <center>
            <div class="alert alert-success" id="alert-message-notification">
                <a href="#" class="close" data-dismiss="alert">&times;</a>
                <center>{{ Session::get('message') }}</center>
            </div>
        </center>
        @endif

        <div class="box-content">
            <table class="table table-striped table-bordered bootstrap-datatable datatable">
                <thead>
                <tr>
                    <th>Role name</th>
                    <th>Last updated</th>
                    <th>Status</th>
                    <th>Actions<a class="btn btn-success" id="actions" href="{{ URL::to('role/add') }}">
                            <i class="icon-plus-sign icon-white"></i>Add</a>
                    </th>
                </tr>
                </thead>
                <tbody>
                @foreach($roles as $key => $value)
                <tr>
                    <td>{{ ucfirst( $value->name ) }}</td>
                    @if ($value->modified)
                    <td class="center">{{ date( "d-m-Y H:i:s", $value->modified ) }}</td>
                    @else
                    <td class="center">{{ date( "d-m-Y H:i:s", $value->created ) }}</td>
                    @endif
                    <td class="center">
                        @if ($value->status == $statusEnabled )
                        <span class="label label-success">Active</span>
                        @else
                        <span class="label label-important">Inactive</span>
                        @endif
                    </td>
                    <td class="center">
                        <a class="btn btn-info" href="{{ URL::to('role/edit/' . $value->id) }}">
                            <i class="icon-edit icon-white"></i>Edit</a>
                        <a class="btn btn-danger" href="{{ URL::to('role/status/' . $value->id) }}"
                           onclick="if(!confirm('Are you sure to toggle status this item?')){return false;};">
                            <i class="icon-ban-circle icon-white"></i>Status</a>
                    </td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <!--/span-->

</div><!--/row-->
<!-- content ends -->
@stop