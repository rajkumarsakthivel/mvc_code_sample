@extends('Site::layouts.main')
@section('content')
<div>
    <ul class="breadcrumb">
        <li>
            <a href="{{ URL::to('site/dashboard') }}">Home</a> <span class="divider">/</span>
        </li>
        <li>
            <a href="{{ URL::to('role/list') }}">User Roles</a>
        </li>
    </ul>
</div>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-edit"></i>&nbsp;Add user roles</h2>
        </div>
        <div class="box-content">
            {{ Form::open( array( 'url'=>'role/create', 'class'=>'form-horizontal' ) ) }}
            <fieldset>
                <ul class="error-notification">
                    @foreach( $errors->all() as $error )
                    <li><p class="alert alert-error">{{ $error }}</p></li>
                    @endforeach
                </ul>
                <div class="control-group">
                    <label class="control-label" for="focusedInput">User role name</label>

                    <div class="controls">
                        {{ Form::text( 'role_name', null, array( 'class'=>'input-xlarge', 'placeholder'=>'Role name' ) ) }}
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="focusedInput">Description</label>

                    <div class="controls">
                        {{ Form::textarea( 'role_description', null, array( 'class'=>'cleditor' ) ) }}
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="focusedInput">Status</label>

                    <div class="controls">
                        {{ Form::select( 'role_status', array( '' => 'Select options','1' => 'Enabled', '0' =>
                        'Disabled' ) ) }}
                    </div>
                </div>

                <div class="form-actions">
                    {{ Form::submit( 'Add', array( 'class'=>'btn btn-primary' ) )}}
                    {{ Form::reset( 'Reset', array( 'class'=>'btn btn-primary' ) )}}
                </div>
            </fieldset>
            {{ Form::close() }}
        </div>
    </div>
    <!--/span-->

</div><!--/row-->

@stop			
			
			