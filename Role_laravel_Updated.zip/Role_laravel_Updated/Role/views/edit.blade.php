@extends('Site::layouts.main')
@section('content')
<div>
    <ul class="breadcrumb">
        <li>
            <a href="{{ URL::to('site/dashboard') }}">Home</a> <span class="divider">/</span>
        </li>
        <li>
            <a href="{{ URL::to('role/list') }}">User Roles</a>
        </li>
    </ul>
</div>

<div class="row-fluid sortable">
    <div class="box span12">
        <div class="box-header well" data-original-title>
            <h2><i class="icon-edit"></i>&nbsp;Edit user roles</h2>
        </div>
        <div class="box-content">
            {{ Form::open( array( 'url'=>'role/update', 'class'=>'form-horizontal' ) ) }}
            <fieldset>
                <ul class="error-notification">
                    @foreach( $errors->all() as $error )
                    <li><p class="alert alert-error" style="width:40%;">{{ $error }}</p></li>
                    @endforeach
                </ul>
                {{ Form::hidden( 'role_id', Input::old( 'role_id', $roles->id ) ) }}
                <div class="control-group">
                    <label class="control-label" for="focusedInput">User role name</label>

                    <div class="controls">
                        {{ Form::text( 'role_name', Input::old( 'role_name', $roles->name ), array(
                        'class'=>'input-xlarge', 'placeholder'=>'Role name' ) ) }}
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="focusedInput">Description</label>

                    <div class="controls">
                        {{ Form::textarea( 'role_description', Input::old( 'role_description', $roles->description ),
                        array( 'class'=>'cleditor' ) ) }}
                    </div>
                </div>
                <div class="control-group">
                    <label class="control-label" for="focusedInput">Status</label>

                    <div class="controls">
                        <select name="role_status">
                            <option value="1" <?php if ( $roles->status == $statusEnabled ) { ?> selected <?php } ?> > Enabled
                            </option>
                            <option value="0"  <?php if ( $roles->status == $statusDisabled ) { ?> selected <?php } ?> > Disabled
                            </option>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    {{ Form::submit( 'Edit', array( 'class'=>'btn btn-primary' ) )}}
                    {{ Form::reset( 'Reset', array( 'class'=>'btn btn-primary' ) )}}
                </div>
            </fieldset>
            {{ Form::close() }}
        </div>
    </div>
    <!--/span-->

</div><!--/row-->

@stop			
			
			