<?php
/**
 * file name : Role.php
 * @version   v.1
 * @author    Rajkumar sakthivel
 * 
 */
namespace Src\xxx\xxx\Models;

use Illuminate\Database\Eloquent\Model as Eloquent;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Request;
use Illuminate\Support\Facades\Validator;
use Src\xxx\User\Models\User;
use Src\xxx\Activity\Models\Activity;

class Role extends Eloquent
{

    public $timestamps    = false;
    const STATUS_ENABLED  = 1;
    const STATUS_DISABLED = 0;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table      = 'pct_roles';
    protected $primaryKey = 'id';

    /**
     * table validation
     */
    public static $rules = array( 'role_name'   => 'required|alpha_spaces|min:2|unique:pct_roles,name',
                                  'role_status' => 'required',
                                );

    /**
     * table validation edit
     */
    public static $rulesEdit = array( 'role_name'   => 'required|alpha_spaces|min:2',
                                      'role_status' => 'required',
                                    );

    /**
     * get active roles list.
     * @return mixed
     */
    public static function getActiveRoles()
    {
        $activeRoles = Role::where( 'status', '!=', self::STATUS_DISABLED )->lists( 'name', 'id' );
        return $activeRoles;
    }

    /**
     * get role name
     * @param int $roleId
     * @return array
     */

    public static function getRoleName( $roleId )
    {
        $roleName = DB::table( 'xxx_roles' )
            ->where( 'id', '=', $roleId )
            ->select( 'name' )
            ->get();
        return array_shift( $roleName );
    }

    /**
     * add new role.
     * @param mixed $input
     */
    public static function addRole( array $input )
    {
        $role              = new Role;
        $role->name        = trim( $input['role_name'] );
        $role->description = trim( $input['role_description'] );
        $role->status      = $input['role_status'];
        $role->created     = time();
        $role->save();
        // add activity
        foreach ( $role["original"] as $key => $value ) {
            if ( $key != 'created' && $key != 'modified' && $key != 'id' ) {
                Activity::addActivity( 'role',
                    $key,
                    $value,
                    'ADDED',
                    $role->id,
                    $role->name
                );
            }
        }
    }

    /**
     * Edit specified role.
     * @param mixed $input
     */
    public static function updateRole( array $input )
    {
        $roleOldData       = Role::find( $input['role_id'] );
        $role              = Role::find( $input['role_id'] );
        $role->name        = trim( $input['role_name'] );
        $role->description = trim( $input['role_description'] );
        $role->status      = $input['role_status'];
        $role->modified    = time();
        $role->save();
        // update activity
        $roleCompare = User::array_difference( $roleOldData["original"],
            $role["original"]
        );
        if ( !empty( $roleCompare ) ) {
            foreach ( $roleCompare as $key => $value ) {
                if ( $key != 'created' && $key != 'modified' && $key != 'id' ) {
                    $updateActivity = Activity::updateActivity( 'role',
                        $key,
                        $roleOldData[$key],
                        $role[$key],
                        'UPDATED',
                        $role->id,
                        $roleOldData->name
                    );
                }
            }
        }
    }

    /**
     * toggle status specified role.
     * @param int $roleId
     */
    public static function toggleRoleStatus( $roleId )
    {
        $roleOldData = Role::find( $roleId );
        $role        = Role::find( $roleId );
        if ( $role->status == self::STATUS_ENABLED ) {
            $role->status = self::STATUS_DISABLED;
        } else {
            $role->status = self::STATUS_ENABLED;
        }
        $role->modified = time();
        $role->save();
        // update activity
        $updateActivity = Activity::updateActivity( 'role',
            'status',
            $roleOldData->status,
            $role->status,
            'UPDATED',
            $role->id,
            $roleOldData->name
        );
    }

}