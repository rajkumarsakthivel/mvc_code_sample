<?php
/**
 * file name : RoleController.php
 * @version   v.1
 * @author    Rajkumar sakthivel
 * 
 */
namespace Src\xxx\Role\Controllers;

use App\Controllers\BaseController;
use Src\xxx\Role\Models\Role;
use Src\xxx\User\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use View;

class RoleController extends BaseController
{

    protected $currentRoute = null;
    protected $hasAccess = false;
    const STATUS_ENABLED    = 1;
    const STATUS_DISABLED   = 0;

    public function __construct( Auth $currentRoute, User $hasAccess )
    {
        $this->beforeFilter( 'csrf', array( 'on' => 'post' ) );
        $this->beforeFilter( 'auth', array( 'only' => array( 'getList',
                                                             'getAdd',
                                                             'postCreate',
                                                             'getEdit',
                                                             'postUpdate',
                                                             'getStatus'
                                                            ) ) );
        $this->currentRoute = User::routeClass();
        if ( Auth::check() ) {
            $this->hasAccess = User::isAllowed();
        }
    }

    /**
     * access page error message
     * @return string
     */
    protected function errorAccess()
    {
        return Redirect::to( 'site/dashboard' )
                     ->with( 'message',
                             'You have no permission to access ' . $this->currentRoute . '!'
                           );
    }

    /**
     * Display a listing of the roles.
     * @return array
     */
    public function getList()
    {
        if ( !$this->hasAccess ) {
            return $this->errorAccess();
        }
            $roles = Role::orderBy( 'id', 'DESC' )->get();
            return View::make( 'Role::list' )
                       ->with( 'statusEnabled', self::STATUS_ENABLED )
                       ->with( 'roles', $roles );
    }

    /**
     * Show the form for creating a new role.
     * @return string
     */
    public function getAdd()
    {
        if ( !$this->hasAccess ) {
            return $this->errorAccess();
        }
            return View::make( 'Role::add' );
    }

    /**
     * Store a newly created role in storage.
     * @return array
     */
    public function postCreate()
    {
        $validator = Validator::make( Input::all(), Role::$rules );
        if ( $validator->passes() ) {
            $roleAdd = Role::addRole( Input::all() );
            return Redirect::to( 'role/list' )
                         ->with( 'message', 'Role added successfully!' );
        } else {
            return Redirect::to( 'role/add' )
                         ->with( 'message', 'The following errors occurred' )
                         ->withErrors( $validator )
                         ->withInput();
        }
    }

    /**
     * Show the form for editing the specified role.
     * @param  int $roleId
     * @return array
     */
    public function getEdit( $roleId )
    {
        if ( !$this->hasAccess ) {
            return $this->errorAccess();
        }
            // get the Role
            $roles = Role::find( $roleId );
            if ( is_null( $roles ) ) {
                return Redirect::to( 'role/list' );
            } else {
                return View::make( 'Role::edit' )
                           ->with( 'statusEnabled', self::STATUS_ENABLED )
                           ->with( 'statusDisabled', self::STATUS_DISABLED )
                           ->with( 'roles', $roles );
            }
    }

    /**
     * Update the specified role in storage.
     * @return array
     */
    public function postUpdate()
    {
        $currentRole = Role::find( Input::get( 'role_id' ) );
        if ( $currentRole->name != trim( Input::get( 'role_name' ) ) ) {
            $validator = Validator::make( Input::all(), Role::$rules );
        } else {
            $validator = Validator::make( Input::all(), Role::$rulesEdit );
        }
        if ( $validator->passes() ) {
            $roleUpdate = Role::updateRole( Input::all() );
            return Redirect::to( 'role/list' )
                         ->with( 'message', 'Role Edits successfully!' );
        } else {
            return Redirect::to( 'role/edit/' . Input::get( 'role_id' ) )
                         ->with( 'message', 'The following errors occurred' )
                         ->withErrors( $validator )
                         ->withInput();
        }
    }

    /**
     * change status the specified role from storage.
     * @param  int $roleId
     * @return string
     */

    public function getStatus( $roleId )
    {
        if ( !$this->hasAccess ) {
            return $this->errorAccess();
        }
            $role = Role::find( $roleId );
            if ( is_null( $role ) ) {
                return Redirect::to( 'role/list' );
            } else {
                $toggleStatus = Role::toggleRoleStatus( $roleId );
                return Redirect::to( 'role/list' )
                             ->with( 'message', 'Role status changed successfully!' );
            }
    }

}