<?php

/**
 * file name : routes.php
 * @version  v.1
 * @author    Rajkumar sakthivel 
 * 
 */

Route::controller( 'role', 'Src\xxx\Role\Controllers\RoleController' );